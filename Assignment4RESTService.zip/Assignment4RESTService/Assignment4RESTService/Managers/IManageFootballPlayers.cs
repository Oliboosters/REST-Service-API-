﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ModelLibrary.Model;

namespace Assignment4RESTService.Managers
{
    public interface IManageFootballPlayers
    {
        IEnumerable<Football_Player> Get();
        Football_Player Get(int id);
        bool Create(Football_Player player);
        bool Update(int id, Football_Player player);
        Football_Player Delete(int id);
    }
}
