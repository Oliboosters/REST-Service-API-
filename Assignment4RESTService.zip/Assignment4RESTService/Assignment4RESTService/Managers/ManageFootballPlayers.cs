﻿using ModelLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4RESTService.Managers
{
    public class ManageFootballPlayers : IManageFootballPlayers
    {
        private static readonly List<Football_Player> playerList = new List<Football_Player>()
        {
            new Football_Player(1, "Sonic", 1991, 15),
            new Football_Player(2, "Miles Tails", 1992, 8),
            new Football_Player(3, "Knuckles", 1993, 16),
            new Football_Player(4, "Amy Rose", 1992, 12)
        };

        public bool Create(Football_Player player)
        {
            playerList.Add(player);
            return true;
        }

        public Football_Player Delete(int id)
        {
            Football_Player footballPlayer = Get(id);
            playerList.Remove(footballPlayer);

            return footballPlayer;
        }

        public IEnumerable<Football_Player> Get()
        {
            return new List<Football_Player>(playerList);
        }

        public Football_Player Get(int id)
        {
            return playerList.Find(p => p.ID == id);
        }

        public bool Update(int id, Football_Player player)
        {
            Football_Player footballPlayer = Get(id);
            if (footballPlayer != null)
            {
                footballPlayer.ID = player.ID;
                footballPlayer.Name = player.Name;
                footballPlayer.Price = player.Price;
                footballPlayer.ShirtNumber = player.ShirtNumber;

                return true;
            }
            else return false;
        }
    }
}
