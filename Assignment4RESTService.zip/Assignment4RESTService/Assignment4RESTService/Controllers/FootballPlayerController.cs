﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ModelLibrary.Model;
using Assignment4RESTService.Managers;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Assignment4RESTService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FootballPlayerController : ControllerBase
    {

        private readonly IManageFootballPlayers mgr = new ManageFootballPlayers();

        // GET: api/<FootballPlayerController>
        [HttpGet]
        public IEnumerable<Football_Player> Get()
        {
            return mgr.Get();
        }

        // GET api/<FootballPlayerController>/5
        [HttpGet("{id}")]
        public Football_Player Get(int id)
        {
            return mgr.Get(id);
        }

        // POST api/<FootballPlayerController>
        [HttpPost]
        public bool Post([FromBody] Football_Player value)
        {
            return mgr.Create(value);
        }

        // PUT api/<FootballPlayerController>/5
        [HttpPut("{id}")]
        public bool Put(int id, [FromBody] Football_Player value)
        {
            return mgr.Update(id, value);
        }

        // DELETE api/<FootballPlayerController>/5
        [HttpDelete("{id}")]
        public Football_Player Delete(int id)
        {
            return mgr.Delete(id);
        }
    }
}
